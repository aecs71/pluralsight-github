module.exports = require('./LottieView');
