import { intersection } from "./index";
export = intersection;
