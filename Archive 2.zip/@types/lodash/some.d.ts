import { some } from "./index";
export = some;
