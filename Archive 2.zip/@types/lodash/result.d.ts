import { result } from "./index";
export = result;
