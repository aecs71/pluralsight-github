import { extendWith } from "../fp";
export = extendWith;
