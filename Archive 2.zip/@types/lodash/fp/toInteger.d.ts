import { toInteger } from "../fp";
export = toInteger;
