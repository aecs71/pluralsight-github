import { times } from "../fp";
export = times;
