import { remove } from "../fp";
export = remove;
