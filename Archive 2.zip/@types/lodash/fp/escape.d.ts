import { escape } from "../fp";
export = escape;
