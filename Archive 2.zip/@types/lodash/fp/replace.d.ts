import { replace } from "../fp";
export = replace;
