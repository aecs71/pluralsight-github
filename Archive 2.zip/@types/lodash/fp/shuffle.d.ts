import { shuffle } from "../fp";
export = shuffle;
