import { curryN } from "../fp";
export = curryN;
