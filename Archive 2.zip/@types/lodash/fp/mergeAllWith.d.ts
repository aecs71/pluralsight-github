import { mergeAllWith } from "../fp";
export = mergeAllWith;
