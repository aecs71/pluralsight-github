import { compact } from "../fp";
export = compact;
