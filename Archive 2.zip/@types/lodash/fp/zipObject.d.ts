import { zipObject } from "../fp";
export = zipObject;
