import { takeLast } from "../fp";
export = takeLast;
