import { sortedIndexOf } from "../fp";
export = sortedIndexOf;
