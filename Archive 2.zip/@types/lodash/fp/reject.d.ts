import { reject } from "../fp";
export = reject;
