import { whereEq } from "../fp";
export = whereEq;
