import { now } from "../fp";
export = now;
