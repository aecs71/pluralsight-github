import { trim } from "../fp";
export = trim;
