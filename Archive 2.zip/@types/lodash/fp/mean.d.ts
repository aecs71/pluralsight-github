import { mean } from "../fp";
export = mean;
