import { at } from "../fp";
export = at;
