import { take } from "../fp";
export = take;
