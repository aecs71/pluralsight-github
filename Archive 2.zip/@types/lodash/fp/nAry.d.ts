import { nAry } from "../fp";
export = nAry;
