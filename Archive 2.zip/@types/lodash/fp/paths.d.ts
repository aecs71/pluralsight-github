import { paths } from "../fp";
export = paths;
