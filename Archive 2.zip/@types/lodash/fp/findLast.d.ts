import { findLast } from "../fp";
export = findLast;
