import { forEach } from "./index";
export = forEach;
