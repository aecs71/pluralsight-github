import { flatMapDepth } from "./index";
export = flatMapDepth;
