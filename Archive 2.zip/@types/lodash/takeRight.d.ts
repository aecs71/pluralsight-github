import { takeRight } from "./index";
export = takeRight;
