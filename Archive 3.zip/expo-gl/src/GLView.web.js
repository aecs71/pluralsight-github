// @flow

import React from 'react';
import { Text, View } from 'react-native';

export default class GLView extends React.Component<{}> {
  render() {
    return (
      <View>
        <Text>GLView Component not supported on the web</Text>
      </View>
    );
  }
}
