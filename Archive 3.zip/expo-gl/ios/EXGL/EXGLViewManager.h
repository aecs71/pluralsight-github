// Copyright 2016-present 650 Industries. All rights reserved.

#import <EXCore/EXViewManager.h>
#import <EXCore/EXModuleRegistryConsumer.h>

@interface EXGLViewManager : EXViewManager <EXModuleRegistryConsumer>

@end
