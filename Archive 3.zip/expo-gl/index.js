module.exports = {
  get GLView() {
    return require('./src/GLView').default;
  },
};
