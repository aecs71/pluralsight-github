module.exports = {
  get FileSystem() {
    return require('./src/FileSystem');
  },
};
