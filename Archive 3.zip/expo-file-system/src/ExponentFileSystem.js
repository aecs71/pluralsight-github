import { NativeModulesProxy } from 'expo-core';
export default NativeModulesProxy.ExponentFileSystem;
