module.exports = require('./lib/stacktrace-parser.js');
