module.exports = {
  get FaceDetector() {
    return require('./src/FaceDetector');
  },
};
