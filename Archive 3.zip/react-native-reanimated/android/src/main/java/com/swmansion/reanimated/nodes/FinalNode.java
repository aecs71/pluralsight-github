package com.swmansion.reanimated.nodes;

public interface FinalNode {
  void update();
}
