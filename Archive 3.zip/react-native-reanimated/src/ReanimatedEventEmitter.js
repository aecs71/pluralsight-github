import ReanimatedModule from './ReanimatedModule';
import { NativeEventEmitter } from 'react-native';

export default new NativeEventEmitter(ReanimatedModule);
