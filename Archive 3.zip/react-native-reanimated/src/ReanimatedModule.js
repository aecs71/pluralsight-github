import { NativeModules } from 'react-native';

const { ReanimatedModule } = NativeModules;

export default ReanimatedModule;
