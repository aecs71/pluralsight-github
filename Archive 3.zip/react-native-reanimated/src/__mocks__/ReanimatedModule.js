export default {
  configureNativeProps: () => {},
  connectNodes: () => {},
  disconnectNodes: () => {},
};
