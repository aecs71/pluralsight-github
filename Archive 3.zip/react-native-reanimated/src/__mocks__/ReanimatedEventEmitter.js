export default {
  addListener: () => {},
  removeAllListeners: () => {},
};
