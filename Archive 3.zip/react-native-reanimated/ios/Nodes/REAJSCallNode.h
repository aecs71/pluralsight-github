#import "REANode.h"

@interface REAJSCallNode : REANode

@end
