#import "REANode.h"

@interface REAAlwaysNode : REANode <REAFinalNode>
@end
