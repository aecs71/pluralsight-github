#import "REANode.h"

@interface REABezierNode : REANode

@end
