#import "REANode.h"

@interface REAClockNode : REANode
@end

@interface REAClockOpNode : REANode
@end

@interface REAClockStartNode : REAClockOpNode
@end

@interface REAClockStopNode : REAClockOpNode
@end

@interface REAClockTestNode : REAClockOpNode
@end
