#import "REANode.h"

@interface REACondNode : REANode

@end
